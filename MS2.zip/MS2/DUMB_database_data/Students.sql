/*
-- Query: SELECT * FROM catelog.Students
-- Date: 2020-11-11 20:15
*/
INSERT INTO `` (`st_name`,`ID`,`GPA`) VALUES ('Andrew',900123456,4.0);
