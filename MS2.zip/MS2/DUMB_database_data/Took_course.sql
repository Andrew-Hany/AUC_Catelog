/*
-- Query: SELECT * FROM catelog.Took_course
-- Date: 2020-11-11 20:15
*/
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900123456,'CSCE',1001,'A',2018,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900123456,'CSCE',1101,'B',2019,'spring');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900123456,'CSCE',1102,'A',2019,'spring');
