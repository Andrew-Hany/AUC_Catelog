/*
-- Query: SELECT * FROM catelog.StudentsMajor
-- Date: 2020-11-11 20:16
*/
INSERT INTO `` (`ID`,`major_code`) VALUES (900123456,'CSCE');
