/*
-- Query: SELECT * FROM sql12379028.verifid_review
-- Date: 2020-11-29 22:39
*/
INSERT INTO `` (`ID`,`major_code`,`course_number`,`rating`,`Text_review`,`verified`) VALUES (900185052,'ACCT',2001,5,'sdadad',1);
INSERT INTO `` (`ID`,`major_code`,`course_number`,`rating`,`Text_review`,`verified`) VALUES (900185052,'ACCT',2002,2,'adssdasd',1);
INSERT INTO `` (`ID`,`major_code`,`course_number`,`rating`,`Text_review`,`verified`) VALUES (900185052,'ACCT',3001,2,'doable',1);
INSERT INTO `` (`ID`,`major_code`,`course_number`,`rating`,`Text_review`,`verified`) VALUES (900185052,'ACCT',3002,3,'asdasd',1);
INSERT INTO `` (`ID`,`major_code`,`course_number`,`rating`,`Text_review`,`verified`) VALUES (900185052,'ACCT',3005,2,'Very good',1);
INSERT INTO `` (`ID`,`major_code`,`course_number`,`rating`,`Text_review`,`verified`) VALUES (900185052,'CSCE',1000,4,'asdasdsaasd',1);
INSERT INTO `` (`ID`,`major_code`,`course_number`,`rating`,`Text_review`,`verified`) VALUES (900185052,'DSCI',1411,5,'one of the best courses i have ever taken',0);
