/*
-- Query: SELECT * FROM sql12379028.Took_course
-- Date: 2020-11-29 22:37
*/
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ACCT',2001,'A',2001,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ACCT',2002,'A',2001,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ACCT',3001,'A',2001,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ACCT',3002,'A',2001,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ACCT',3003,'A',2020,'f');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ACCT',3004,'A',2001,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ACCT',3005,'A',2001,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ACCT',3006,'A',2001,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ACCT',4000,'A',2020,'f');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ARIC',1099,'B+',2009,'spring');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ARIC',1101,'A',2001,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ARIC',1300,'C',2000,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'ARIC',2099,'A',2002,'fall');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'CSCE',1000,'A',2020,'f');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'CSCE',1001,'A',2001,'spring');
INSERT INTO `` (`ID`,`major_code`,`course_number`,`letter_grade`,`year`,`semester`) VALUES (900185052,'CSCE',1101,'A',0,'fall');
