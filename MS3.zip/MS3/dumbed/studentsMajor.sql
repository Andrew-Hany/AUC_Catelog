/*
-- Query: SELECT * FROM sql12379028.StudentsMajor
-- Date: 2020-11-29 22:37
*/
INSERT INTO `` (`ID`,`major_code`) VALUES (900185052,'CSCE');
