/*
-- Query: SELECT * FROM sql12379028.Students
-- Date: 2020-11-29 22:36
*/
INSERT INTO `` (`st_name`,`ID`,`GPA`) VALUES ('Andrew',900185052,3.5);
