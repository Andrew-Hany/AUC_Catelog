/*
-- Query: SELECT * FROM sql12379028.Review
-- Date: 2020-11-29 22:38
*/
INSERT INTO `` (`major_code`,`course_number`,`ID`,`rating`,`Text_review`) VALUES ('ACCT',2001,900185052,5,'sdadad');
INSERT INTO `` (`major_code`,`course_number`,`ID`,`rating`,`Text_review`) VALUES ('ACCT',2002,900185052,2,'adssdasd');
INSERT INTO `` (`major_code`,`course_number`,`ID`,`rating`,`Text_review`) VALUES ('ACCT',3001,900185052,2,'doable');
INSERT INTO `` (`major_code`,`course_number`,`ID`,`rating`,`Text_review`) VALUES ('ACCT',3002,900185052,3,'asdasd');
INSERT INTO `` (`major_code`,`course_number`,`ID`,`rating`,`Text_review`) VALUES ('ACCT',3005,900185052,2,'Very good');
INSERT INTO `` (`major_code`,`course_number`,`ID`,`rating`,`Text_review`) VALUES ('CSCE',1000,900185052,4,'asdasdsaasd');
INSERT INTO `` (`major_code`,`course_number`,`ID`,`rating`,`Text_review`) VALUES ('DSCI',1411,900185052,5,'one of the best courses i have ever taken');
